﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using YYGMessageSend.Common;
using System.Threading;
using System.IO;
using System.Web;
using YYGMessageSend.Model;

namespace YYGMessageSend
{
    public partial class frmMain : Form
    {
        // Ini文件访问类
        private IniFile _IniFile = null;
        private int WaitLen = 30;
        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (null == _IniFile)
            {
                string path = Application.StartupPath + "\\setting.ini";
                _IniFile = new IniFile(path);
                if (!File.Exists(path))
                {
                    SaveSetting();
                }
                
            }

            txturl.Text = _IniFile.ReadString("Model", "URL", "");
            WaitLen = _IniFile.ReadInteger("Model", "WaitLen", 30);
        }

        private void SaveSetting()
        {
            _IniFile.WriteString("Model", "URL", txturl.Text);
            _IniFile.WriteString("Model", "WaitLen", "30");
        }
        string URL = "";
        private void btnstart_Click(object sender, EventArgs e)
        {
            btnstart.Enabled = false;
            URL = txturl.Text;
            if (string.IsNullOrEmpty(URL))
            {
                ShowMsg("发送地址不存在。");
                return;
            }
            Thread th = new Thread(Send);
            th.IsBackground = true;
            th.Start();
        }
        HttpHelper mhttp = new HttpHelper();


        private void Send()
        {
            int mTime = WaitLen;
            if (mTime < 5)
            {
                mTime = 5;
            }
            do
            {
                try
                {
                    string html = mhttp.GetHtml(URL, Encoding.UTF8);
                    AjaxReturnOR obj = html.ParseJSON<AjaxReturnOR>();
                    if (obj != null)
                    {
                        ShowMsg(obj.msg);
                    } 
                    for (int i = mTime; i > 0; i--)
                    {
                        SetNumber(i.ToString());
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    ShowMsg(ex.Message);
                }
            } while (true);
        }

        public static string encodeUnicode(string str)
        {
            Encoding encodingUTF = Encoding.UTF8;
            string strDestination = string.Empty;
            byte[] encodedBytes = encodingUTF.GetBytes(str);
            for (int i = 0; i < encodedBytes.Length; i++)
            {
                strDestination += BitConverter.ToString(encodedBytes, i, 1);
            }
            return strDestination;
        }


        //private string ConvertChar(string sIn)
        //{
          
        //    if (sIn.IndexOf("\\u") >= 0)
        //    {
        //        string sOut = "";//转换后
        //        //sOut = encodeUnicode(sIn);

        //        string[] arr = sIn.Split(new string[] { "\\u" }, StringSplitOptions.RemoveEmptyEntries);
        //        foreach (string s in arr)
        //        {
        //          Char c=  Convert.ToInt32(s);
        //            sOut += new string( s).ToString(); ;
        //        }
        //        return sOut;
        //    }
        //    else
        //    {
        //        return sIn;
        //    } 
        //}

        #region 显示信息
        //显示信息
        delegate void SetMsg(string msg);
        delegate void SetNum(string msg);

        /// <summary>
        /// 显示信息到日志列表。
        /// </summary>
        /// <param name="strMsg"></param>
        private void ShowMsg(string strMsg)
        {
            if (rtbmsg.InvokeRequired)
            {
                SetMsg ms = new SetMsg(ShowMsg);
                rtbmsg.Invoke(ms, new object[] { strMsg });
            }
            else
            {
                //rtbMsg.Text = strMsg +"\r\n" + rtbMsg.Text;
                rtbmsg.AppendText(MsgNumber.ToString() + "  " + DateTime.Now.ToString("HH:mm:ss") + "\r\n"+ strMsg + "\r\n");
                MsgNumber++;
                if (MsgNumber == 1000)
                    rtbmsg.Clear();
            }
        }

        int MsgNumber = 0;


        private void SetNumber(string strMsg)
        {
            if (lblmsg.InvokeRequired)
            {
                SetNum ms = new SetNum(SetNumber);
                lblmsg.Invoke(ms, new object[] { strMsg });
            }
            else
            {
                lblmsg.Text = strMsg;
            }
        }

        
        #endregion



    }


}

