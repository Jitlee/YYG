﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Drawing;

namespace YYGMessageSend.Common
{
    public class HttpHelper
    {
        #region 私有变量
        private CookieContainer cc;
        private string contentType = "application/x-www-form-urlencoded; charset=UTF-8";
        private string accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
        private string userAgent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1) Gecko/20090624 Firefox/3.5";
        //private Encoding encoding = Encoding.GetEncoding("GB2312");
        private int connectTimeOutRetryTryMaxTimes = 3;
        private int currentTry = 0;
        #endregion



        #region 属性
        /// <summary>
        /// Cookie容器
        /// </summary>
        public CookieContainer CookieContainer
        {
            get
            {
                return cc;
            }
            set
            {
                cc = value;
            }
        }

        /// <summary>
        /// 获取网页源码时使用的编码
        /// </summary>
        /// <value></value>
        //public Encoding Encoding
        //{
        //    get
        //    {
        //        return encoding;
        //    }
        //    set
        //    {
        //        encoding = value;
        //    }
        //}

        /// <summary>
        /// 连接超时的重试次数
        /// </summary>
        public int ConnectTimeOutRetryTryMaxTimes
        {
            get
            {
                return connectTimeOutRetryTryMaxTimes;
            }
            set
            {
                connectTimeOutRetryTryMaxTimes = value;
            }
        }

        //private IWebProxy webProxy;
        ///// <summary>
        ///// 网络代理
        ///// </summary>
        //public IWebProxy WebProxy
        //{
        //    set
        //    {
        //        webProxy = value;
        //    }
        //}

        private Uri responseUri;
        public Uri ResponseUri
        {
            get
            {
                return responseUri;
            }
            set
            {
                responseUri = value;
            }
        }


        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpHelper"/> class.
        /// </summary>
        public HttpHelper()
        {
            cc = new CookieContainer();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpHelper"/> class.
        /// </summary>
        /// <param name="cc">The cc.</param>
        public HttpHelper(CookieContainer cc)
        {
            this.cc = cc;
            if (cc == null) cc = new CookieContainer();
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="HttpHelper"/> class.
        /// </summary>
        /// <param name="cc">The cc.</param>
        public HttpHelper(CookieCollection cookieC)
        {
            Uri muri = new Uri("http://www.easipay.net");
            if (cc == null) cc = new CookieContainer();
            foreach (Cookie c in cookieC)
            {
                cc.Add(muri, c);
            }

        }



        public string GetHtml(string url)
        {
            return GetHtml(url, Encoding.GetEncoding("gb2312"));
        }

        /// <summary>
        /// 获取指定页面的HTML代码
        /// </summary>
        /// <param name="url">指定页面的路径</param>
        /// <param name="cookieCollection">Cookie集合</param>
        /// <returns></returns>
        public string GetHtml(string url, Encoding encode)
        {
            currentTry++;
            try
            {
                HttpWebRequest httpWebRequest;
                httpWebRequest = (HttpWebRequest)HttpWebRequest.Create(url);
                httpWebRequest.CookieContainer = cc;
                httpWebRequest.ContentType = contentType;
                //httpWebRequest.Referer = "http://www.easipay.net/taps/index.shtml";
                httpWebRequest.Accept = accept;
                httpWebRequest.UserAgent = userAgent;
                httpWebRequest.Method = "GET";


                HttpWebResponse httpWebResponse;
                httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();


                responseUri = httpWebResponse.ResponseUri;
                Stream responseStream = httpWebResponse.GetResponseStream();
                cc.Add(
                httpWebResponse.Cookies);
                StreamReader streamReader = new StreamReader(responseStream, encode);
                string html = streamReader.ReadToEnd();
                streamReader.Close();
                responseStream.Close();

                CookieCollection mloginCC = httpWebResponse.Cookies;
                CookieSInfo = mloginCC;
                currentTry = 0;
                return html;// +"\r\n" + responseHeader;
            }
            catch
            {
                currentTry = 0;
                return string.Empty;
            }
        }
        /// <summary>
        /// 获取指定页面的HTML代码
        /// </summary>
        /// <param name="url">指定页面的路径</param>
        /// <param name="cookieCollection">Cookie集合</param>
        /// <returns></returns>
        public string GetHtml_ForDetail(string url, Encoding encode)
        {
            currentTry++;
            try
            {
                HttpWebRequest httpWebRequest;
                httpWebRequest = (HttpWebRequest)HttpWebRequest.Create(url);
                httpWebRequest.CookieContainer = cc;
                httpWebRequest.ContentType = contentType;
                //httpWebRequest.Referer = "http://www.easipay.net/taps/index.shtml";
                httpWebRequest.Accept = accept;
                httpWebRequest.UserAgent = userAgent;
                httpWebRequest.Method = "GET";


                HttpWebResponse httpWebResponse;
                httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();


                responseUri = httpWebResponse.ResponseUri;
                Stream responseStream = httpWebResponse.GetResponseStream();
                cc.Add(httpWebResponse.Cookies);
                StreamReader streamReader = new StreamReader(responseStream, encode);
                string html = streamReader.ReadToEnd();
                streamReader.Close();
                responseStream.Close();

                CookieCollection mloginCC = httpWebResponse.Cookies;
                CookieSInfo = mloginCC;
                currentTry = 0;
                return html;// +"\r\n" + responseHeader;
            }
            catch
            {
                currentTry = 0;
                return string.Empty;
            }
        }

        public CookieCollection CookieSInfo { get; set; }

        public Bitmap GetStream(string url)
        {
            Uri uri = new Uri(url);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);

            request.UserAgent = userAgent;
            request.Accept = accept;
            request.ContentType = this.contentType;
            request.Referer = "http://www.easipay.net/taps/index.shtml";
            request.CookieContainer = cc;

            Stream responseStream = request.GetResponse().GetResponseStream();
            Bitmap bitmap = new Bitmap(responseStream, true);
            string responseHeader = ((HttpWebResponse)request.GetResponse()).GetResponseHeader("Set-Cookie");
            //cok = GetCookie(responseHeader);
            responseStream.Close();
            return bitmap;
        }



        public string PostSearchSpaceMessage(string Url, string postDataStr, Encoding m_codeRead, Encoding mWritCod)
        {
            string str = "";
            try
            {
                System.Net.ServicePointManager.Expect100Continue = false;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);

                request.Method = "POST";
                request.KeepAlive = true;
                request.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";


                request.Accept = "*/*";
                request.Referer = "http://www.easipay.net/taps/index.shtml";
                request.UserAgent = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)";
                request.AllowAutoRedirect = false;
                //request.ContentLength = 140;
                request.CookieContainer = cc;

                System.Net.ServicePointManager.Expect100Continue = false;
                StreamWriter writer = new StreamWriter(request.GetRequestStream(), mWritCod);
                writer.Write(postDataStr);
                writer.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                response.GetResponseHeader("Set-Cookie");
                Stream responseStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(responseStream, m_codeRead);
                str = reader.ReadToEnd();
                reader.Close();
                responseStream.Close();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            return str;
        }



        #region Cookie处理
        public Cookie GetCookie(string strCookie)
        {
            CookieCollection ccl = cc.GetCookies(new Uri("http://www.easipay.net"));
            foreach (Cookie c in ccl)// Cookie c in cc)
            {
                if (c.Name == strCookie)
                    return c;
            }
            return null;
        }

        public string GetCookieString()
        {
            CookieCollection ccl = cc.GetCookies(new Uri("http://www.easipay.net"));
            if (ccl != null && ccl.Count > 0)
                return CookieCollectionToString(CookieSInfo);
            return "";
        }

        /// <summary>
        /// 将COOKIE字符串转成COOKIE集合
        /// </summary>
        /// <param name="strCookie">COOKIE字符串</param>
        /// <returns></returns>
        public static CookieCollection StringToCookieCollection(string strCookie)
        {
            CookieCollection cookies = new CookieCollection();
            string[] strArray = strCookie.TrimEnd(new char[] { ';' }).Split(new char[] { ';' });
            foreach (string str in strArray)
            {
                string[] strArray2 = str.Split(new char[] { '=' });
                if (strArray2[0].Trim() != "")
                {
                    Cookie c = new Cookie();
                    c.Name = strArray2[0].Trim();
                    c.Value = strArray2[1].Trim();
                    if (strArray2.Length > 2)
                    {
                        c.Value += "=" + strArray2[2].Trim();
                    }
                    c.Value = c.Value.Split(',')[0];
                    cookies.Add(c);
                }
            }
            return cookies;
        }
        /// <summary>
        /// 将COOKIE集合转成COOKIE字符串
        /// </summary>
        /// <param name="cookies">COOKIE集合</param>
        /// <returns></returns>
        public static string CookieCollectionToString(CookieCollection cookies)
        {
            string str = string.Empty;
            if ((cookies != null) && (cookies.Count > 0))
            {
                foreach (Cookie cookie in cookies)
                {
                    string name = cookie.Name;
                    string str3 = cookie.Value;
                    str = str + string.Format("{0}={1};", name, str3);
                }
            }
            return str;
        }
        #endregion

    }
}
